#!/bin/bash
# ═══════════════════════════════════════════════════════════════
#  push_to_github.sh
#  Run this script ONCE inside your mdm_full/ folder on Kali.
#  It will initialize git, commit all files, and push to GitHub.
#
#  Usage:
#    chmod +x push_to_github.sh
#    ./push_to_github.sh
# ═══════════════════════════════════════════════════════════════

set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

echo -e "${CYAN}${BOLD}"
echo "  ██████╗ ██╗████████╗██╗  ██╗██╗   ██╗██████╗ "
echo " ██╔════╝ ██║╚══██╔══╝██║  ██║██║   ██║██╔══██╗"
echo " ██║  ███╗██║   ██║   ███████║██║   ██║██████╔╝"
echo " ██║   ██║██║   ██║   ██╔══██║██║   ██║██╔══██╗"
echo " ╚██████╔╝██║   ██║   ██║  ██║╚██████╔╝██████╔╝"
echo "  ╚═════╝ ╚═╝   ╚═╝   ╚═╝  ╚═╝ ╚═════╝ ╚═════╝ "
echo -e "  MDM System → GitHub Pusher${NC}"
echo ""

# ── Step 1: Collect GitHub info ───────────────────────────────
echo -e "${YELLOW}Enter your GitHub details:${NC}"
echo ""
read -p "  GitHub Username: " GH_USER
read -p "  Repository name (e.g. ai-mdm-system): " GH_REPO
read -p "  Your email (for git config): " GH_EMAIL
echo ""
echo -e "${CYAN}  Repo will be: https://github.com/${GH_USER}/${GH_REPO}${NC}"
echo ""

# ── Step 2: Install GitHub CLI if not present ─────────────────
if ! command -v gh &>/dev/null; then
    echo -e "${YELLOW}[*] Installing GitHub CLI...${NC}"
    curl -fsSL https://cli.github.com/packages/githubcli-archive-keyring.gpg \
        | sudo dd of=/usr/share/keyrings/githubcli-archive-keyring.gpg
    echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/githubcli-archive-keyring.gpg] \
        https://cli.github.com/packages stable main" \
        | sudo tee /etc/apt/sources.list.d/github-cli.list > /dev/null
    sudo apt update -y && sudo apt install gh -y
    echo -e "${GREEN}[✓] GitHub CLI installed${NC}"
else
    echo -e "${GREEN}[✓] GitHub CLI already installed${NC}"
fi

# ── Step 3: Authenticate with GitHub ─────────────────────────
echo ""
echo -e "${YELLOW}[*] Authenticating with GitHub...${NC}"
echo -e "${CYAN}    A browser window will open — log in and authorize.${NC}"
echo -e "${CYAN}    Or use a Personal Access Token when prompted.${NC}"
echo ""
gh auth login --web 2>/dev/null || gh auth login

# ── Step 4: Configure Git ─────────────────────────────────────
echo ""
echo -e "${YELLOW}[*] Configuring git...${NC}"
git config --global user.name  "$GH_USER"
git config --global user.email "$GH_EMAIL"
git config --global init.defaultBranch main
echo -e "${GREEN}[✓] Git configured${NC}"

# ── Step 5: Create .gitignore ─────────────────────────────────
cat > .gitignore << 'GITIGNORE'
# Python
__pycache__/
*.py[cod]
*.pyo
*.egg-info/
dist/
build/
.eggs/

# Virtual environment
venv/
env/
.venv/

# Database & runtime data
data/mdm.db
data/sessions/
reports/

# TLS certs (sensitive)
certs/key.pem
certs/cert.pem

# Streamlit
.streamlit/

# IDE
.vscode/
.idea/
*.swp
*.swo

# OS
.DS_Store
Thumbs.db

# Logs
*.log
*.log.*

# Enrollment manifests (may contain device IDs)
enrolled_devices.json
GITIGNORE

echo -e "${GREEN}[✓] .gitignore created${NC}"

# ── Step 6: Create LICENSE ────────────────────────────────────
cat > LICENSE << 'LICENSE'
MIT License

Copyright (c) 2025 MDM Project Contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
LICENSE

echo -e "${GREEN}[✓] LICENSE created${NC}"

# ── Step 7: Init git repo ─────────────────────────────────────
echo ""
echo -e "${YELLOW}[*] Initializing git repository...${NC}"
if [ ! -d ".git" ]; then
    git init
    echo -e "${GREEN}[✓] Git repo initialized${NC}"
else
    echo -e "${GREEN}[✓] Git repo already exists${NC}"
fi

# ── Step 8: Create GitHub repo ────────────────────────────────
echo ""
echo -e "${YELLOW}[*] Creating GitHub repository...${NC}"
gh repo create "$GH_REPO" \
    --public \
    --description "🛡️ AI-Powered MDM System for Android Fleets | Kali Linux | Python 3 | Ollama AI" \
    --homepage "https://github.com/${GH_USER}/${GH_REPO}" \
    2>/dev/null || echo -e "${YELLOW}[!] Repo may already exist — continuing...${NC}"

echo -e "${GREEN}[✓] GitHub repo ready${NC}"

# ── Step 9: Add remote ────────────────────────────────────────
git remote remove origin 2>/dev/null || true
git remote add origin "https://github.com/${GH_USER}/${GH_REPO}.git"
echo -e "${GREEN}[✓] Remote origin set${NC}"

# ── Step 10: Stage all files ──────────────────────────────────
echo ""
echo -e "${YELLOW}[*] Staging all project files...${NC}"
git add .

# Show what's being committed
echo ""
echo -e "${CYAN}Files to be committed:${NC}"
git status --short
echo ""

# ── Step 11: Commit ───────────────────────────────────────────
git commit -m "🛡️ Initial commit — AI-Powered MDM System v2.0

Features:
- FastAPI backend with WebSocket real-time comms
- Ollama AI (free local LLM) — natural language device commands
- Isolation Forest anomaly detection per device
- MITRE ATT&CK Mobile threat analyzer (15+ detection rules)
- Textual 8.x CLI dashboard (fixed RichLog + fetch_data)
- Streamlit web dashboard with Plotly charts
- Bulk ADB installer for parallel agent deployment
- JWT authentication + bcrypt
- SQLite database with SQLAlchemy ORM
- Auto policy enforcement engine

Bugs Fixed:
- scikit-learn build failure on Python 3.13 (numpy RC version)
- starlette Debian package conflict (venv isolation)
- Textual Log markup= removed in v8 → migrated to RichLog
- StatsPanel refresh() conflict with Textual internals → fetch_data()
- Kali tool dependency conflicts (requirements >= pins)

Stack: FastAPI · Ollama · scikit-learn · Textual · Streamlit · Plotly · SQLite · ADB"

echo -e "${GREEN}[✓] Commit created${NC}"

# ── Step 12: Push ─────────────────────────────────────────────
echo ""
echo -e "${YELLOW}[*] Pushing to GitHub...${NC}"
git push -u origin main

# ── Step 13: Create GitHub Issues for known bugs ──────────────
echo ""
echo -e "${YELLOW}[*] Creating GitHub Issues for known bugs...${NC}"

gh issue create \
    --title "🐛 scikit-learn build fails on Python 3.13 (numpy RC version)" \
    --body "## Description
Installing \`requirements.txt\` fails on Python 3.13 because of pinned numpy RC version.

## Error
\`\`\`
ERROR: Could not find a version that satisfies the requirement numpy==2.0.0rc1
ERROR: Failed to build 'scikit-learn'
\`\`\`

## Root Cause
Old \`requirements.txt\` used exact \`==\` pins with a yanked release candidate (\`numpy==2.0.0rc1\`).

## Fix ✅
Updated \`requirements.txt\` to use \`>=\` flexible pins:
\`\`\`bash
pip install 'numpy>=1.26.4' 'scikit-learn>=1.4.0' --break-system-packages
\`\`\`

## Status
Fixed in this commit. \`requirements.txt\` now uses \`>=\` throughout." \
    --label "bug" 2>/dev/null || true

gh issue create \
    --title "🐛 Cannot uninstall starlette — Debian-managed package" \
    --body "## Description
pip fails to uninstall \`starlette\` because Kali installed it via \`apt\`.

## Error
\`\`\`
× Cannot uninstall starlette 0.50.0
╰─> no RECORD file was found for starlette
hint: The package was installed by debian.
\`\`\`

## Root Cause
Kali Linux installs many Python packages via \`apt\` (Debian managed). pip cannot modify these.

## Fix ✅
Use a virtual environment with \`--system-site-packages\`:
\`\`\`bash
python3 -m venv venv --system-site-packages
source venv/bin/activate
pip install -r requirements.txt
\`\`\`

## Status
Documented. Use venv for all installations." \
    --label "bug" 2>/dev/null || true

gh issue create \
    --title "🐛 Textual Log markup= keyword removed in v8.x" \
    --body "## Description
Dashboard crashes on Textual 8.x because \`Log(markup=True)\` parameter was removed.

## Error
\`\`\`
TypeError: Log.__init__() got an unexpected keyword argument 'markup'
\`\`\`

## Root Cause
Textual 8.x split \`Log\` into two widgets:
- \`Log\` — plain text only
- \`RichLog\` — supports markup, highlight, and rich formatting

## Fix ✅ (applied in \`dashboard/app.py\`)
\`\`\`python
# BEFORE
from textual.widgets import Log
yield Log(id='al', highlight=True, markup=True)
log.write_line('text')

# AFTER
from textual.widgets import RichLog
yield RichLog(id='al', highlight=True, markup=True)
log.write('text')
\`\`\`

## Status
Fixed. All \`Log\` references migrated to \`RichLog\`." \
    --label "bug" 2>/dev/null || true

gh issue create \
    --title "🐛 StatsPanel.refresh() conflicts with Textual 8.x internal call" \
    --body "## Description
Textual 8.x crashes because custom \`refresh()\` method conflicts with built-in widget method.

## Error
\`\`\`
TypeError: StatsPanel.refresh() got an unexpected keyword argument 'layout'
\`\`\`

## Root Cause
Textual 8.x calls \`widget.refresh(layout=True)\` internally during mount. Our custom \`refresh()\` method intercepted this call and crashed because it doesn't accept a \`layout\` argument.

Affected classes: \`DeviceTable\`, \`AlertPanel\`, \`StatsPanel\`

## Fix ✅ (applied in \`dashboard/app.py\`)
Renamed all custom \`refresh()\` methods to \`fetch_data()\`:
\`\`\`python
# BEFORE (broken)
async def refresh(self): ...
self.set_interval(5, self.refresh)

# AFTER (fixed)
async def fetch_data(self): ...
self.set_interval(5, self.fetch_data)
\`\`\`

## Rule
Never name Textual widget methods \`refresh()\`, \`compose()\`, or \`mount()\` — these are reserved internal Textual methods.

## Status
Fixed in all three widget classes." \
    --label "bug" 2>/dev/null || true

gh issue create \
    --title "⚠️ Kali tool dependency conflicts (non-breaking warnings)" \
    --body "## Description
Installing packages shows many dependency conflict warnings due to Kali's pre-installed tools.

## Warning Output
\`\`\`
theharvester 4.10.1 requires fastapi==0.129.2, but you have fastapi 0.118.0
mitmproxy 12.2.1 requires mitmproxy_rs<0.13
flask-limiter 3.12 requires rich<14
faradaysec 5.19.0 requires bcrypt<5.0.0
\`\`\`

## Root Cause
Kali Linux pre-installs security tools (mitmproxy, theharvester, faradaysec) with tightly pinned dependencies that conflict with our packages.

## Impact
⚠️ **These are warnings only** — MDM packages install correctly. Kali tools may break if you run them after installing our packages into the system Python.

## Fix ✅
Use virtual environment to fully isolate:
\`\`\`bash
python3 -m venv venv --system-site-packages
source venv/bin/activate
pip install -r requirements.txt
\`\`\`
This keeps both MDM and Kali tools working independently.

## Status
Documented. Virtual environment usage is now recommended in README." \
    --label "documentation" 2>/dev/null || true

echo -e "${GREEN}[✓] GitHub Issues created${NC}"

# ── Done ──────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}${BOLD}═══════════════════════════════════════════════════${NC}"
echo -e "${GREEN}${BOLD}  ✅ Successfully pushed to GitHub!${NC}"
echo -e "${GREEN}${BOLD}═══════════════════════════════════════════════════${NC}"
echo ""
echo -e "  📦 Repository : ${CYAN}https://github.com/${GH_USER}/${GH_REPO}${NC}"
echo -e "  🐛 Issues     : ${CYAN}https://github.com/${GH_USER}/${GH_REPO}/issues${NC}"
echo -e "  📋 Code       : ${CYAN}https://github.com/${GH_USER}/${GH_REPO}/tree/main${NC}"
echo ""
echo -e "${YELLOW}  Next: Star your repo and share the link! ⭐${NC}"
echo ""
